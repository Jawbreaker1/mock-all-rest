package com.engwall.restservice.MockAllRest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MockAllRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
